import './App.css'
import Footer from './assets/komponen/Footer'
import Hero from './assets/komponen/Hero'
import Navbar from './assets/komponen/Navbar'

function App() {
 

  return (
    <>
    <div>
    <Navbar />
    <Hero />
    <Footer />
    </div>
   

    </>
   )
}

export default App
