import styled from "styled-components"

function Navbar() {
    const Ppl =styled.div`
    background-color: red;
    padding: 50px
    `

    let title = "my landing page"

    return(

        <>
        <Ppl>
        {title}
        
        </Ppl>
        </>
    )

}


export default Navbar